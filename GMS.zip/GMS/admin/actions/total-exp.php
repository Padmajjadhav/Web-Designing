<?php

$con = mysqli_connect(
    'sql308.infinityfree.com',    // Example: sql306.infinityfree.com
    'if0_38764349',// Example: epiz_12345678
    'Abhisheksandy',// (you will type manually)
    'if0_38764349_gymnsb'   // Example: epiz_12345678_gym
);

if(!$con){
    die("Connection Failed");
}

$sql = "SELECT SUM( amount) FROM equipment";
        $amountsum = mysqli_query($con, $sql) or die(mysqli_error($sql));
        $row_amountsum = mysqli_fetch_assoc($amountsum);
        $totalRows_amountsum = mysqli_num_rows($amountsum);
        echo $row_amountsum['SUM( amount)'];
?>