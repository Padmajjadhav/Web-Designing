<?php
$con = mysqli_connect(
    'sql308.infinityfree.com',    // Example: sql306.infinityfree.com
    'if0_38764349',// Example: epiz_12345678
    'Abhisheksandy',// (you will type manually)
    'if0_38764349_gymnsb'   // Example: epiz_12345678_gym
);

if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>
